import React from "react";
import {Card, Form, Input, Button, Icon, Breadcrumb} from "antd";
import Avatar from "../../components/uploadAvatar";
import axios from "axios";
import {CREATE_NEW_PROJECT} from "../../components/api";
import {Redirect} from "react-router-dom";

const FormItem = Form.Item;

const formItemLayout = {
  labelCol: {
    xs: {span: 24},
    sm: {span: 5},
  },
  wrapperCol: {
    xs: {span: 24},
    sm: {span: 18},
    md: {span: 16},
    lg: {span: 12},
  },
};

class CreateProject extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      avatarSrc: "XX",
      redirect: false,
      buttonDisplay:'none'
    }
  }

  onUpdate = (val) => {
    this.setState({
      avatarSrc: val,
      buttonDisplay:"block"
    })
  };

  handleSubmit = e => {
    const avatar = this.state.avatarSrc;
    e.preventDefault();
    var self = this;
    this.props.form.validateFields((err, values) => {
      if (!err) {
              axios.post(CREATE_NEW_PROJECT, {
              project_name: values.projectName,
              client_name: values.clientName,
              avatar: avatar
              })
              .then(function (response) {
                console.log(response);
                if(response.status===200){
                  //window.location.href = "/stark/uploads";
                  console.log("Success");
                  self.setState({
                    redirect: true,
                    uniqueId: response.data
                  })
                }
              })
              .catch(function (error) {
                console.log(error);
              });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    if (this.state.redirect === true) {
      return <Redirect to={'/stark/uploads/'+this.state.uniqueId} />
    }
  return (
    <Card className="gx-card" title="Create New Project">
    <Breadcrumb>
    <Breadcrumb.Item>Home</Breadcrumb.Item>
    <Breadcrumb.Item><span className="gx-link">New Project</span></Breadcrumb.Item>
    </Breadcrumb>
    <br/><br/>
      <Form onSubmit={this.handleSubmit}>
      <FormItem
      label = "Project Name"
      {...formItemLayout}>
        {getFieldDecorator('projectName', {
          rules: [{ required: true, message: 'Please input your project name!' }],
        })(
          <Input
            prefix={<Icon type="project" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter a name for your project" id="project" autoComplete="off"
          />,
        )}
      </FormItem>
      <FormItem
      label = "Client Name"
      {...formItemLayout}>
        {getFieldDecorator('clientName', {
          rules: [{ required: true, message: 'Please input your client\'s name!' }],
        })(
          <Input
            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter a client's name" id="client" autoComplete="off"
          />,
        )}
      </FormItem>
        <FormItem
        {...formItemLayout}
        label="Avatar"
        hasFeedback
          >
          <Avatar onUpdate={this.onUpdate}/>
        </FormItem>

        <Button style={{display: this.state.buttonDisplay}} block type="primary" shape="round" htmlType="submit" className="login-form-button">
<Icon type="right-circle" theme="filled"/>Create Now!
          </Button>
      </Form>
    </Card>
  );
}
}

const WrappedForm = Form.create({ name: 'new_project_form' })(CreateProject);

export default WrappedForm;
