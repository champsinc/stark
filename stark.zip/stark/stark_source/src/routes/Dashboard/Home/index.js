import React from "react";
import ProjectCard from "../../components/projectCard";
import {Row, Col, Button, Icon, Layout, Card, Breadcrumb} from "antd";
import {Link} from "react-router-dom";
import {PROJECTS_DATA_URL} from "../../components/api";
import axios from "axios";

class Dashboard extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      data: <Col sm={24}><h1><center>You currently have no projects. Try creating one!</center></h1><br/></Col>
    }
  }

  componentDidMount(){
    var self = this;
    axios.get(PROJECTS_DATA_URL, {
    company_id: '<ENTER_COMPANY_ID_HERE>'
    })
    .then(function (response) {
      if(response.status===200){
        let __data__ = response.data;
        let data = __data__.map(project => {
                   return (
                    <Col key={project.uniqueId} sm={8} xs={24}>
                    <ProjectCard uniqueId={project.uniqueId} imageLink={project.avatar_link} date={project.timestamp} name={project.projectName} company={project.clientName} progress={project.percentage}/>
                    </Col>
                 );
        });
        if(__data__.length>0)
          self.setState({data: data});
      }
    })
    .catch(function (error) {
      console.log(error);
    });
  }

  render(){
  return (
    <Layout>
    <Card className="gx-card" title="All Projects">
      <Breadcrumb>
      <Breadcrumb.Item>Home</Breadcrumb.Item>
      <Breadcrumb.Item><span className="gx-link">Dashboard</span></Breadcrumb.Item>
      </Breadcrumb>
    </Card>
    <Row>
        {this.state.data}
    </Row>
    <Link to="/stark/create">
      <Button block type="primary" shape="round"> <Icon type="right-circle" theme="filled"/>  Solve a new problem</Button>
    </Link>
    </Layout>
  );
};
};
export default Dashboard;
