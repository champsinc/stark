import React from "react";
import PICard from "../../components/piCard";
import DCCard from "../../components/dcCard";
import OGrid from "../../components/projectOverviewGrid";
import EcommerceStatus from "../../../components/Metrics/EcommerceStatus.js";
import IconWithTextCard from "../../../components/Metrics/IconWithTextCard.js";
import {Row, Col, Layout, Card, Button, Icon, Breadcrumb} from "antd";
import Widget from "components/Widget/index";
import {Link} from "react-router-dom";
import {PROJECT_DASHBOARD_STATS, DELETE_PROJECT} from "../../components/api";
import axios from "axios";

const data = [
  {
    key: '1',
    name: 'Potholes (P)',
    transfer: '2 hrs. ago',
    status: 'Completed',
    color: 'green'
  },
  {
    key: '2',
    name: 'Manholes (M)',
    transfer: '17 days ago',
    status: 'In Progress',
    color: 'orange'
  },
  {
    key: '3',
    name: 'Road Markings (R)',
    transfer: '1 month ago',
    status: 'In Progress',
    color: 'orange'
  },
  {
    key: '4',
    name: 'Large Objects (L)',
    transfer: '1 month ago',
    status: 'Not Started',
    color: 'red'
  }
];

class ProjectDetails extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      uniqueId: props.match.params.id,
      imageCount: "",
      collectedData: [],
      ppData: [],
      ppCount:"",
      modelStatsCount: "",
      modelStatsIterations: "",
      deleteRedirectOn: ""
    };

    var self = this;

    /* Validator begins */
    try {
      var valid = props.location.state.validated;
      console.log(valid);
    }
    catch(e){
      return window.location.href = '/stark/validation/'+props.match.params.id+'/projectView';
    }
    /* Validator ends */

    axios.get(PROJECT_DASHBOARD_STATS+"?projectId="+self.state.uniqueId, {
    data: 'data'
    })
    .then(function (response) {
       if(response.status===200){

         var dcStatsCount = response.data[0]["dcStats"][0]["imageCount"];
         var dcStats = response.data[0]["dcStats"][0]["labelDistribution"];
         var annStatsCount = response.data[0]["annStats"][0]["annotationCount"];
         var annStats = response.data[0]["annStats"][0]["labelDistribution"];
         var modelStatsCount = response.data[0]["modStats"][0]["modelCount"];
         var modelStatsIterations = response.data[0]["modStats"][0]["lastModelIteration"];

         self.setState({
           imageCount: dcStatsCount,
           collectedData: dcStats,
           ppCount: annStatsCount,
           ppData: annStats,
           modelCount: modelStatsCount,
           modelStatsIterations: modelStatsIterations
         });
       }
     });
   }

  delete_project(self){
    axios.get(DELETE_PROJECT+"?uniqueId="+self.state.uniqueId, {
    data: 'data'
    })
    .then(function (response) {
         console.log("Project Deleted");
         window.location.href="https://champsinc.github.io/stark"
     });
  }

  render(){
  return (
    <Layout>
    <Breadcrumb>
    <Breadcrumb.Item>Home</Breadcrumb.Item>
    <Breadcrumb.Item><span className="gx-link">Project Summary</span></Breadcrumb.Item>
    </Breadcrumb>
    <br/>
    <OGrid/>
    <Row>
      <Col sm={12} xs={24}>
        <PICard data={data}/>
        <Row>
            <Col sm={12} xs={24}>
              <EcommerceStatus icon="components" title="DarkFlow" subTitle="Source: @thtrieu on GitHub" color="orange" colorTitle="geekblue" colorSubTitle="geekblue"/>
            </Col>
            <Col sm={12} xs={24}>
              <EcommerceStatus icon="culture-calendar" title="TensorFlow" subTitle="Source: @tensorflow on GitHub" color="geekblue" colorTitle="pink" colorSubTitle="pink"/>
            </Col>
        </Row>

        <Card title="Deployment">
          <Row>
              <Col sm={8} xs={24}>
                <Button block type="primary" shape="round"> <Icon type="link"/>URL</Button>
              </Col>
              <Col sm={8} xs={24}>
                <Button block type="primary" shape="round"> <Icon type="database" theme="filled"/>Database</Button>
              </Col>
              <Col sm={8} xs={24}>
                <Button block type="primary" shape="round"> <Icon type="api" theme="filled"/>API</Button>
              </Col>
          </Row>
         </Card>
    </Col>
    <Col sm={12} xs={24}>
    <Link to={"/stark/mediaView/"+this.props.match.params.id}>
    <DCCard collectedData = {this.state.collectedData} totalCount = {this.state.imageCount} cardTitle = {"Data Collection"} cardSubTitle = {"Total Image Count"} colorId="color1" color1="#845EC2" color2="#FF55AA"/>
    </Link>
    <a href={"https://champsinc.github.io/annotations/?**"+this.props.match.params.id} target="_blank" rel="noopener noreferrer">
    <DCCard collectedData = {this.state.ppData} totalCount = {this.state.ppCount} cardTitle = {"Annotations Data"} cardSubTitle = {"After Annotating Count"} colorId="color2" color1="#001A7C" color2="#B0ADE4"/>
    </a>
    <Link to={"/stark/training/"+this.props.match.params.id}>
    <Widget
      title={
        <h2 className="h4 gx-text-capitalize gx-mb-0">
          Training</h2>
      }>
    <IconWithTextCard title={this.state.modelCount} subTitle="Model Iterations" icon="visits" iconColor="white" cardColor="cyan"/>
    <IconWithTextCard title={this.state.modelStatsIterations} subTitle="Last Model Iteration" icon="modal" iconColor="white" cardColor="red"/>
    </Widget>
    </Link>
    <Button type="danger" block onClick={() => this.delete_project(this)}>Delete Project Entirely</Button>
    </Col>
    </Row>
    {this.deleteRedirectOn}
    </Layout>
  );
};
};
export default ProjectDetails;
