import React from "react";
import ProblemSelector from "../../../components/selectProblem";
import UploadPicture from "../../../components/uploadPicture";
import {Link} from "react-router-dom";
import {Button, Icon, Card, Breadcrumb} from "antd";

class MediaUpload extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      problemSelected: 'none',
      problemValue: '',
    }

    try {
      var valid = props.location.state.validated;
      console.log(valid);
    }
    catch(e){
      return window.location.href = '/stark/validation/'+props.match.params.id+'/uploads';
    }

  }

  problemIsSelected = (val) => {
    this.setState({
      problemSelected: val
    })
  };
  problemValue = (val) => {
    this.setState({
      problemValue: val
    })
  };

 render(props){
    return (
    <div>
    <Breadcrumb>
    <Breadcrumb.Item>Home</Breadcrumb.Item>
    <Breadcrumb.Item><span className="gx-link">Media Uploads</span></Breadcrumb.Item>
    </Breadcrumb>
    <br/>
    <ProblemSelector problemIsSelected={this.problemIsSelected} problemValue={this.problemValue}/>
    <Card className="gx-card" title="Upload Media Files" style={{display:this.state.problemSelected}}>
    <UploadPicture uniqueId={this.props.match.params.id} problemValue = {this.state.problemValue}/>
    </Card>
    <Link to={"/stark/mediaView/"+this.props.match.params.id}>
      <Button block type="primary" shape="round"> <Icon type="right-circle" theme="filled"/>Go to project's collection!</Button>
    </Link>
    </div>
  );
};
};
export default MediaUpload;
