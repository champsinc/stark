import React from "react";
import GalleryIM from "../../../../components/photoGallery";
import {Row, Col, Button, Icon, Breadcrumb} from "antd";
import AnnotationComponent from "../../../../components/annotation";
import {Link} from "react-router-dom";


class MediaView extends React.Component {

  constructor(props){
    super(props);

    /* Validator begins */
    try {
      var valid = props.location.state.validated;
      console.log(valid);
    }
    catch(e){
      return window.location.href = '/stark/validation/'+props.match.params.id+'/mediaView';
    }
    /* Validator ends */
  }

  render(){
  return (
    <div>

    <Breadcrumb>
    <Breadcrumb.Item>Home</Breadcrumb.Item>
    <Breadcrumb.Item><span className="gx-link">Collection Preview</span></Breadcrumb.Item>
    </Breadcrumb>
    <br/>
    <Row>
      <Col sm={10}></Col>
      <Col sm={8}>
          <AnnotationComponent uniqueId={this.props.match.params.id} />
      </Col>
       <Col sm={6}>
        <Link to={"/stark/uploads/"+this.props.match.params.id}>
            <Button block shape="round" type="primary"><Icon type="file-add" theme="filled"/> Add more data</Button>
        </Link>
      </Col>
    </Row>
    <br/>
    <Row>
      <Col xl={24} lg={24} md={24} sm={12} xs={24}>
        <GalleryIM uniqueId={this.props.match.params.id}/>
      </Col>
    </Row>
    </div>
  );
};
}
export default MediaView;
