import React from "react";
import AnnotationComponent from "../../../components/annotation";

const PreprocessView = () => {
  return (
    <div>
    <AnnotationComponent/>
    </div>
  );
};
export default PreprocessView;
