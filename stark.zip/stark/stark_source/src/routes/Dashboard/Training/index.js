import React from "react";
import {Button, Card, Col, Row, Breadcrumb, Icon} from "antd";
import {Browser} from "react-window-ui";
import PRCard from "../../components/prCard";
import axios from "axios";
import LoadingIndicator from "../../components/loadingIndicator";
import {
  INITIATE_TRAINING_PROCESS,
  TRAINING_PARAMETERS_SETUP,
  BEGIN_TRAINING,
  STOP_TRAINING,
  CHECK_TRAINING_ON,
  CONTINUE_TRAINING,
  TRAINING_SUMMARY,
  TRAINING_LOGS,
  RESET_TRAINING
} from "../../components/api";

const prData = [
  {Label: '0.1', Counter: 1},
  {Label: '0.2', Counter: 1},
  {Label: '0.3', Counter: 1},
  {Label: '0.4', Counter: 1},
  {Label: '0.5', Counter: 0.57},
  {Label: '0.6', Counter: 0.57},
  {Label: '0.7', Counter: 0.57},
  {Label: '0.8', Counter: 0.57},
  {Label: '0.9', Counter: 0.51},
  {Label: '1.0', Counter: 0.51}
];

class Training extends React.Component {
  constructor(props){
    super(props);

    /* Validator begins */
    try {
      var valid = props.location.state.validated;
      console.log(valid);
    }
    catch(e){
      return window.location.href = '/stark/validation/'+props.match.params.id+'/training';
    }
    /* Validator ends */

    this.state={
      projectId: props.match.params.id,
      initiateDisplay: "none",
      parameterSetupDisplay: "none",
      beginTrainingDisplay:"none",
      viewLogsDisplay:"none",
      trainingLog: <div><Icon type="sync" spin/>{" Fetching console state ..."}</div>,
      inProgressProcessing: false,
      modelFiles: <i><Icon type="sync" spin/>{" Fetching ... "}</i>,
      timeElasped: <i><Icon type="sync" spin/>{" Fetching ..."}</i>,
      lastCheckpoint:<i><Icon type="sync" spin/>{" Fetching ..."}</i>,
      stopTraining:"none",
      continueTraining:"none",
      downloadLogs: "none"
    }

    /*{this.checkTrainingStatus(this)}*/
    setInterval(() => {
      this.checkTrainingStatus(this);
    }, 6000);
    setInterval(() => {
      this.getTrainingSummary(this);
    }, 6000);

  }

  checkTrainingStatus(self){

    /*"https://wegmaniac.ga/global_scripts/try.php"*/
    axios.get(CHECK_TRAINING_ON+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(self.state.inProgressProcessing){
        console.log("In Progress");
      }
      else if(response.data==="Run init darkflow"){
        self.setState({
          initiateDisplay: "block",
          parameterSetupDisplay: "none",
          beginTrainingDisplay:"none",
          viewLogsDisplay:"none",
          trainingLog: "",
          downloadLogs:"none"
        });
      }
      else if(response.data==="Run darkflow parameters"){
        self.setState({
          parameterSetupDisplay: "block",
          initiateDisplay: "none",
          beginTrainingDisplay:"none",
          viewLogsDisplay:"none",
          trainingLog: "",
          downloadLogs:"none"
        });
      }
      else if(response.data==="Run begin training"){
        self.setState({
          beginTrainingDisplay: "block",
          parameterSetupDisplay: "none",
          initiateDisplay: "none",
          viewLogsDisplay:"none",
          trainingLog: "",
          downloadLogs:"none"
        });
      }
      else if(response.data==="Running"){
        self.viewTrainingLogs(self);
        self.setState({
          stopTraining:"block",
          continueTraining:"none",
          beginTrainingDisplay: "none",
          parameterSetupDisplay: "none",
          initiateDisplay: "none",
          trainingLog:"",
          downloadLogs:"block"
        });
      }
      else if(response.data==="Stopped"){
        self.setState({
          continueTraining: "block",
          stopTraining:"none",
          beginTrainingDisplay: "none",
          parameterSetupDisplay: "none",
          initiateDisplay: "none",
          viewLogsDisplay:"none",
          trainingLog:"Training has been paused/stopped. To continue press the continue training button below.",
          downloadLogs:"block"
        });
      }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         trainingLog: "Training console inactive at this time!"
       });
     });
  }

  initiateTrainingProcess(self){
    self.setState({
      trainingLog : <div><Icon type="sync" spin/>{" Initiating training process"}</div>,
      initiateDisplay: "none",
      inProgressProcessing: true
    });
    /*"https://jsonplaceholder.typicode.com/posts/1"*/
    axios.get(INITIATE_TRAINING_PROCESS+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
       if(response.status===200){
         self.setState({
           trainingLog : "Training process initiated.",
           parameterSetupDisplay : "block",
           inProgressProcessing: false
         });
       }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         trainingLog : "Training process had been initiated earlier / cannot be initiated at this time.",
         inProgressProcessing:false
       });
     });
  }

  setupTrainingParameters(self){
    self.setState({
      trainingLog : <div><Icon type="sync" spin/>{" Setting up training parameters"}</div>,
      parameterSetupDisplay: "none",
      inProgressProcessing:true
    });
    axios.get(TRAINING_PARAMETERS_SETUP+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
       if(response.status===200){
         self.setState({
           trainingLog : "Training parameters have been setup.",
           beginTrainingDisplay: "block",
           inProgressProcessing:false
         });
       }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         trainingLog : "Training parameters had been setup earlier / cannot be setup at this time.",
         inProgressProcessing:false
       });
     });
  }

  beginTrainingProcess(self){
    self.setState({
      trainingLog : <div><Icon type="sync" spin/>{" Starting with training ... "}</div>,
      beginTrainingDisplay: "none",
      inProgressProcessing:true
    });
    axios.get(BEGIN_TRAINING+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);


       if(response.data==="Less than 50" && response.status===200){
         self.setState({
           trainingLog : "A minimum of 50 images need to be uploaded for training to begin!",
           inProgressProcessing:false
         });
       }
       else if(response.status===200){
         self.setState({
           trainingLog : "Training process has begun!",
           viewLogsDisplay: "block",
           inProgressProcessing:false
         });
       }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         trainingLog : "Training cannot be started at this moment!",
         inProgressProcessing:false
       });
     });
  }

  viewTrainingLogs(self){
    self.setState({
      trainingLog : <LoadingIndicator/>,
      viewLogsDisplay: "none",
      inProgressProcessing:true
    });
    axios.get(TRAINING_LOGS+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(response.status===200){
        var dataArr = response.data.split("\n");
        dataArr.reverse();
        var logString = dataArr.join("\n");
        self.setState({
          trainingLog : <pre>{logString}</pre>,
          inProgressProcessing:false
        });
      }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         trainingLog : "Logs cannot be viewed at this time!",
         inProgressProcessing:false
       });
     });
  }

  resetTraining(self){
    self.setState({
      stopTraining: "none",
      continueTraining:"none"
    });
    axios.get(RESET_TRAINING+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(response.status===200){
        alert("Training instance has been reset!");
      }
     })
     .catch(function (error) {
       console.log(error);
       alert("Unable to reset at this moment!");
     });
  }

  getTrainingSummary(self){
    /*"https://jsonplaceholder.typicode.com/posts/2"*/
    axios.get(TRAINING_SUMMARY+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(response.status===200){
        self.setState({
          modelFiles: response.data["modelFiles"],
          timeElasped: response.data["timestamp"],
          lastCheckpoint:response.data["lastCheckpoint"]
        });
      }
     })
     .catch(function (error) {
       console.log(error);
       self.setState({
         modelFiles: "Unable to fetch at this time!",
         timeElasped: "Unable to fetch at this time!",
         lastCheckpoint:"Unable to fetch at this time!"
       });
     });
  }

  stopTraining(self){
    axios.get(STOP_TRAINING+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(response.status===200){
        alert("Training has been paused/stopped, To continue press the continue training button!");
      }
     })
     .catch(function (error) {
       console.log(error);
       alert("Failed to stop/pause training at the moment. Try later!");
     });
  }

  continueTraining(self){
    axios.get(CONTINUE_TRAINING+"?projectId="+self.state.projectId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
      if(response.status===200){
        alert("Training has continued from where it was stopped last! Press the view logs button on the console to see the logs");
      }
     })
     .catch(function (error) {
       console.log(error);
       alert("Failed to continue training at the moment. Try later!");
     });
     /*{this.getTrainingSummary(this)}*/
  }

  render(){
    return(
      <div>

      <Breadcrumb>
      <Breadcrumb.Item>Home</Breadcrumb.Item>
      <Breadcrumb.Item><span className="gx-link">Training</span></Breadcrumb.Item>
      </Breadcrumb>
      <br/>
      <Browser resize height="25.5em">
      <h3>Training Instance Console</h3>

      <p>{this.state.trainingLog}</p>
      <Button style={{display:this.state.initiateDisplay}} onClick={() => this.initiateTrainingProcess(this)} type="dashed"><b>Initiate Training Process</b></Button>
      <Button style={{display:this.state.parameterSetupDisplay}} onClick={() => this.setupTrainingParameters(this)} type="dashed"><b>Setup Training Parameters</b></Button>
      <Button style={{display:this.state.beginTrainingDisplay}} onClick={() => this.beginTrainingProcess(this)} type="dashed"><b>Start With Training</b></Button>
      <Button style={{display:this.state.viewLogsDisplay}} onClick={() => this.viewTrainingLogs(this)} type="dashed"><b>View Training Logs</b></Button>

      </Browser>
      <br/>
      <Row>
      <Col sm={12}>
      <Card className="gx-card" title="Training Instance Summary">
      <div>Model Files Generated: {this.state.modelFiles}</div>
      <div>Time Elasped: {this.state.timeElasped}</div>
      <div>Last Checkpoint @ Step: {this.state.lastCheckpoint}</div>
      <br/>
      <div>
      <Button type="danger" style={{display:this.state.stopTraining}} onClick={() => this.stopTraining(this)}>Pause/Stop Training</Button>
      <Button type="primary" style={{display:this.state.continueTraining}} onClick={() => this.continueTraining(this)}>Continue Training</Button>
      <Button type="primary" style={{display:this.state.downloadLogs}}>Download Complete Logs</Button>
      <Button type="danger" onClick={() => this.resetTraining(this)}>Reset Training</Button>
      <Button type="primary" disabled>Deploy Best Checkpoint</Button>
      </div>
      </Card>
      </Col>
      <Col sm={12}>
      <Card className="gx-card" title="Results and Trials">
      <center>
      <Button type="primary" disabled>View Confusion Matrix</Button>
      <Button type="primary" disabled>View Other Metrics</Button>
      <Button type="primary" disabled>Test Another Dataset</Button>
      </center>
      </Card>
      </Col>
      </Row>
      <Row>
      <Col sm={24}>
      <PRCard collectedData = {prData} score = {"0.927"} cardTitle = {"Dummy Precision Recall Curve"} cardSubTitle = {"Curve Plot On Testing Data"} colorId="color1" color1="#845EC2" color2="#FF55AA"/>
      </Col>
      </Row>
      </div>
    );
  }
}

export default Training;
