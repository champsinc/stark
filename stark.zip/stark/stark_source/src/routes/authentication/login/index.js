import React from "react";
import {Card, Form, Input, Button, Icon} from "antd";
import axios from "axios";
import {LOGIN} from "../../components/api";
import {Redirect} from "react-router-dom";

const FormItem = Form.Item;

const formItemLayout = {
  labelCol: {
    xs: {span: 24},
    sm: {span: 5},
  },
  wrapperCol: {
    xs: {span: 24},
    sm: {span: 18},
    md: {span: 16},
    lg: {span: 12},
  },
};

class Login extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      uniqueId: "NOT_SET"
    };
  }

  handleSubmit = e => {
    e.preventDefault();
    var self = this;
    this.props.form.validateFields((err, values) => {
      if (!err) {
              axios.post(LOGIN, {
              email: values.email,
              password: values.password
              })
              .then(function (response) {
                console.log(response);
                if(response.status===200){
                  self.setState({
                    redirect: true,
                    uniqueId: response.data
                  })
                }
              })
              .catch(function (error) {
                console.log(error);
              });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    if (this.state.redirect === true) {
      return <Redirect to={'/stark/dashboard/'} />
    }
  return (
    <Card className="gx-card" title="Log In">
      <Form onSubmit={this.handleSubmit}>
      <FormItem
      label = "Email"
      {...formItemLayout}>
        {getFieldDecorator('email', {
          rules: [
            {
              type: 'email',
              message: 'The input is not valid E-mail!',
            },
            {
              required: true,
              message: 'Please input your E-mail!',
            },
          ],
        })(
          <Input
            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter your email address" id="email" autoComplete="off"
          />,
        )}
      </FormItem>

      <FormItem
      label = "Password"
      {...formItemLayout}>
        {getFieldDecorator('password', {
          rules: [{ required: true, message: 'Please input your Password!' }],
        })(
          <Input
            prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter your password" type="password" id="password" autoComplete="off"
          />,
        )}
      </FormItem>

        <Button block type="primary" shape="round" htmlType="submit" className="login-form-button">
<Icon type="right-circle" theme="filled"/>Login Now!
          </Button>
      </Form>
    </Card>
  );
}
}

const WrappedForm = Form.create({ name: 'new_login_form' })(Login);

export default WrappedForm;
