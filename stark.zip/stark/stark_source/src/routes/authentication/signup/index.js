import React from "react";
import {Card, Form, Input, Button, Icon} from "antd";
import axios from "axios";
import {SIGNUP} from "../../components/api";
import {Redirect} from "react-router-dom";

const FormItem = Form.Item;

const formItemLayout = {
  labelCol: {
    xs: {span: 24},
    sm: {span: 5},
  },
  wrapperCol: {
    xs: {span: 24},
    sm: {span: 18},
    md: {span: 16},
    lg: {span: 12},
  },
};

class SignUp extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      uniqueId: "NOT_SET"
    };
  }

  handleSubmit = e => {
    e.preventDefault();
    var self = this;
    this.props.form.validateFields((err, values) => {
      if (!err) {
              axios.post(SIGNUP, {
              name: values.name,
              email: values.email,
              password: values.password
              })
              .then(function (response) {
                console.log(response);
                if(response.status===200){
                  self.setState({
                    redirect: true,
                    uniqueId: response.data
                  })
                }
              })
              .catch(function (error) {
                console.log(error);
              });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    if (this.state.redirect === true) {
      return <Redirect to={'/stark/login/'} />
    }
  return (
    <Card className="gx-card" title="Sign Up">
      <Form onSubmit={this.handleSubmit}>
      <FormItem
      label = "Company Name"
      {...formItemLayout}>
        {getFieldDecorator('name', {
          rules: [{ required: true, message: 'Please input your company name!' }],
        })(
          <Input
            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter your company name" id="name" autoComplete="off"
          />,
        )}
      </FormItem>
      <FormItem
      label = "Email"
      {...formItemLayout}>
        {getFieldDecorator('email', {
          rules: [
            {
              type: 'email',
              message: 'The input is not valid E-mail!',
            },
            {
              required: true,
              message: 'Please input your E-mail!',
            },
          ],
        })(
          <Input
            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter a valid email address" id="email" autoComplete="off"
          />,
        )}
      </FormItem>

      <FormItem
      label = "Password"
      {...formItemLayout}>
        {getFieldDecorator('password', {
          rules: [{ required: true, message: 'Please input your Password!' }],
        })(
          <Input
            prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Enter your password" type="password" id="password" autoComplete="off"
          />,
        )}
      </FormItem>

        <Button block type="primary" shape="round" htmlType="submit" className="login-form-button">
<Icon type="right-circle" theme="filled"/>SignUp Now!
          </Button>
      </Form>
    </Card>
  );
}
}

const WrappedForm = Form.create({ name: 'new_signup_form' })(SignUp);

export default WrappedForm;
