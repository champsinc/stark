import React from "react";
import {Route, Switch} from "react-router-dom";

import asyncComponent from "util/asyncComponent";

const App = ({match}) => (
  <div className="gx-main-content-wrapper">
    <Switch>
      <Route path={`${match.url}stark/dashboard`} component={asyncComponent(() => import('./Dashboard/Home'))}/>
      <Route path={`${match.url}stark/uploads/:id`} component={asyncComponent(() => import('./Dashboard/Project_Details/Data_Collection'))}/>
      <Route path={`${match.url}stark/create`} component={asyncComponent(() => import('./Dashboard/Create_Project'))}/>
      <Route path={`${match.url}stark/projectView/:id`} component={asyncComponent(() => import('./Dashboard/Project_Details'))}/>
      <Route path={`${match.url}stark/mediaView/:id`} component={asyncComponent(() => import('./Dashboard/Project_Details/Data_Collection/Collection'))}/>
      <Route path={`${match.url}stark/preprocess`} component={asyncComponent(() => import('./Dashboard/Project_Details/Data_Preprocessing'))}/>
      <Route path={`${match.url}stark/training/:id`} component={asyncComponent(() => import('./Dashboard/Training'))}/>
      <Route path={`${match.url}stark/validation/:id/:destination`} component={asyncComponent(() => import('./components/validation'))}/>
      <Route path={`${match.url}stark/signup`} component={asyncComponent(() => import('./authentication/signup'))}/>
      <Route path={`${match.url}stark/login`} component={asyncComponent(() => import('./authentication/login'))}/>
    </Switch>
  </div>
);

export default App;
