import React from "react";
import { Redirect } from 'react-router-dom';
import axios from "axios";
import {VALIDATE_PROJECT_ID} from "../api";
import LoadingIndicator from "../loadingIndicator";

class Validation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uniqueId: props.match.params.id,
      destination: props.match.params.destination,
      redirectTo: ''
    };

    var self = this;

    axios.get(VALIDATE_PROJECT_ID+"?id="+self.state.uniqueId, {
    data:"data"
    })
    .then(function (response) {
      console.log(response);
       if(response.status===200){
         console.log(response+"Validation Check!");
         //return window.location.href = '/stark/'+self.state.destination+'/'+self.state.uniqueId;
         self.setState({
           redirectTo: <Redirect to={{
            pathname: '/stark/'+self.state.destination+'/'+self.state.uniqueId,
            state: { validated: true }
        }}/>

         });
       }
     })
     .catch(function (error) {
       console.log(error);
       return window.location.href = 'https://champsinc.github.io/404';
     });
  }

  render(){
    return (
      <div>
      <LoadingIndicator styleProp={"block"}/>
      {this.state.redirectTo}
      </div>
    );
  }
}
export default Validation;
