import React, { Component } from "react";
import {DATA_COLLECTION_URL} from "../api";
// Import React FilePond
import { FilePond, File, registerPlugin } from "react-filepond";
// Import FilePond styles
import "filepond/dist/filepond.min.css";
// Import the Image EXIF Orientation and Image Preview plugins
// Note: These need to be installed separately
import FilePondPluginImageExifOrientation from "filepond-plugin-image-exif-orientation";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import FilePondPluginFileValidateSize from "filepond-plugin-file-validate-size";
import FilePondPluginFileValidateType from "filepond-plugin-file-validate-type";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
// Register the plugins
registerPlugin(
  FilePondPluginImageExifOrientation,
  FilePondPluginImagePreview,
  FilePondPluginFileValidateSize,
  FilePondPluginFileValidateType,
);
var file_names = [];
// Our app
class UploadPicture extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // Set initial files
      files: [""],
      uniqueId: props.uniqueId
      //enableNext: props.enableNext
    };
  }

  handleInit() {
    console.log("IMClassify");
  }

  onLoad = e => {
    if (e.includes("Success")) {
      var temp_filename_array = e.split("_");
      file_names.push(temp_filename_array[1]);
      //self.state.enableNext();
    }
  };

  render(props) {
    var session = this.state.uniqueId;
    var tags = this.props.problemValue;
    return (
      <div className="App">
        {/* Pass FilePond properties as attributes */}
        <FilePond
          className="filepond-bg"
          ref={ref => (this.pond = ref)}
          allowFileSizeValidation={true}
          maxFileSize={"2MB"}
          acceptedFileTypes={[
            "image/png",
            "image/jpg",
            "image/jpeg",
            "video/mp4",
            "video/avi"
          ]}
          allowMultiple={true}
          labelFileProcessingComplete={"Upload Complete"}
          maxFiles={9}
          allowRevert={false}
          labelIdle='Drag & Drop your files or <span class="filepond--label-action">Browse</span><br/> <i>Acceptable file types: .png, .jpg, .jpeg, .mp4, .avi</i>'
          server={{
            url: DATA_COLLECTION_URL+"?uniqueId="+session+"&tags="+tags,
            process: {
              onload: this.onLoad
            }
          }}
          oninit={() => this.handleInit()}
          onupdatefiles={fileItems => {
            // Set current file objects to this.state
            this.setState({
              files: fileItems.map(fileItem => fileItem.file)
            });
          }}
        >
          {/* Update current files  */}
          {this.state.files.map(file => (
            <File key={file} src={file} origin="local" />
          ))}
        </FilePond>
      </div>
    );
  }
}

export default UploadPicture;
