import React from "react";
import {Card} from "antd";

const OGrid = () => {
  return (
    <Card title="Project Overview">
      <Card.Grid>Project Completeness</Card.Grid>
      <Card.Grid>User's Progress</Card.Grid>
      <Card.Grid>User Clicks Saved</Card.Grid>
      <Card.Grid>Estimated Working Hours Saved</Card.Grid>
      <Card.Grid>Last Training Instance Date</Card.Grid>
      <Card.Grid>Overall Model Accuracy</Card.Grid>
      <Card.Grid>Deployment Status</Card.Grid>
      <Card.Grid>API Status</Card.Grid>
    </Card>
  );
};

export default OGrid;
