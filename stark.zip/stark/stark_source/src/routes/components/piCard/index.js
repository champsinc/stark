import React from "react";
import {Table, Badge, Button} from "antd";
import Widget from "components/Widget/index";

const columns = [
  {
    title: 'Problem Identified',
    dataIndex: 'image',
    render: (text, record) => {
      return <div className="gx-flex-row gx-align-items-center">
        <p className="gx-mb-0">{record.name}</p>
      </div>
    },
  },
  {
    title: 'When?',
    dataIndex: 'transfer',
    render: (text, record) => {
      return <span className="gx-text-grey">{record.transfer}</span>
    },

  },
  {
    title: 'Status',
    dataIndex: 'status',
    render: (text, record) => {
      return <span className="gx-text-primary gx-pointer">
      <Badge count={text} style={{backgroundColor: record.color, color:'#fff'}}/>
      </span>
    },
  },
];

class PICard extends React.Component {

  constructor(props){
    super(props);
    this.state={
      widgetDisplay: "none",
      buttonText:"Show Demo Problems Identified Card"
    }
  }

  toggleWidget(self){
    if(self.state.widgetDisplay==="none"){
      self.setState({
        widgetDisplay: "block",
        buttonText:"Hide Demo Problems Identified Card"
      });
    }
    else{
      self.setState({
        widgetDisplay: "none",
        buttonText:"Show Demo Problems Identified Card"
      });
    }
  }

  render(){
  return (
    <div>
    <Button block type="primary" onClick={() => this.toggleWidget(this)}>{this.state.buttonText}</Button>
    <div style={{display: this.state.widgetDisplay}}>
    <Widget
      title={
        <h2 className="h4 gx-text-capitalize gx-mb-0">
          Problems Identified</h2>
      } extra={
      <p className="gx-text-primary gx-mb-0 gx-pointer gx-d-none gx-d-sm-block">
        <i className="icon icon-add-circle gx-fs-lg gx-d-inline-flex gx-vertical-align-middle"/> Add A Problem</p>
    }>
      <div className="gx-table-responsive">
        <Table className="gx-table-no-bordered" columns={columns} dataSource={this.props.data} pagination={false}
               size="small"/>
      </div>
      <p className="gx-text-primary gx-mb-0 gx-pointer gx-d-block gx-d-sm-none gx-mb-0 gx-mt-3">
        <i className="icon icon-add-circle gx-fs-lg gx-d-inline-flex gx-vertical-align-middle"/> Add A Problem</p>
    </Widget>
    </div>
    </div>
  );
};
};

export default PICard;
