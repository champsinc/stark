import React from "react";
import {Icon} from "antd";

const LoadingIndicator = (props) => {
  return(
    <div style={{fontSize: '75px', display:props.styleProp, marginLeft:'48%', marginTop:'5%', marginBottom:'5%'}}>
    <Icon type="sync" spin/>
    </div>
  );
}

export default LoadingIndicator;
