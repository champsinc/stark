import React, { Component } from 'react';
import {Button, Icon} from "antd";


class AnnotationComponent extends Component {

  render (props) {

    return (
      <div>
      <a rel="noopener noreferrer" href={"https://champsinc.github.io/annotations/?**"+this.props.uniqueId} target="_blank"><Button block type="primary" shape="round"> <Icon type="right-circle" theme="filled"/>Go to Annotations Section!</Button></a>
      </div>
    )
  }
}

export default AnnotationComponent;
