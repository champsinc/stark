import React from "react";
import {Card, Row, Col, Icon} from "antd";
import axios from "axios";
import {DATA_DISPLAY_URL, DELETE_IMAGE_URL} from "../../components/api";
import LoadingIndicator from "../loadingIndicator";

class GalleryIM extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      uniqueId: props.uniqueId,
      loadingDisplay: 'block'
    };

    var self = this;

    self.setState({
      images: []
    });

    var imag = [];

    axios.get(DATA_DISPLAY_URL+"?project_id="+self.state.uniqueId, {
    data: 'data'
    })
    .then(function (response) {
      console.log(response);
       if(response.status===200){
         console.log(response);
         let images_ = response.data;
         imag = images_.map(image => {
                    return (
                      <Col sm={6}>
                      <Card style={{backgroundColor: '#11111122'}} className="gx-card" title={image.caption}>
                       <img style={{maxHeight:'200px', borderRadius:'5px', border:'1px solid black'}} src={image.src} alt={image.caption} />
                       <Icon onClick={() => self.deleteImage(image.src, self)} style={{marginTop:'10px', float:'right', fontSize:'18px', color:'#111'}} type="delete" theme="filled"/>
                       </Card>
                       </Col>
                  );
                 });
        if(images_.length>0){
        self.setState({
          images: imag,
          loadingDisplay: 'none'
        });
      }
      else{
        self.setState({
          images: [<Col sm={24}><h1><center>Nothing to display, Try adding some file(s).</center></h1></Col>],
          loadingDisplay: 'none'
        });
      }
       }
    })
    .catch(function (error) {
      console.log(error);
    });
  }

  deleteImage(source, self){
    axios.get(DELETE_IMAGE_URL+"?projectId="+self.state.uniqueId+"&src="+source, {
    data: 'data'
    })
    .then(function (response) {
      if(response.status===200){
        window.location.reload();
      }
    });

  }

  render() {
    return (
      <div>
      <br/>
      <LoadingIndicator styleProp={this.state.loadingDisplay}/>
      <Row>
      {this.state.images}
      </Row>
      </div>
    );
  }

}

export default GalleryIM;
