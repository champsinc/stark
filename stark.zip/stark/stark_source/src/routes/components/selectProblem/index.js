import React from "react";
import {Card, Select} from "antd";

const Option = Select.Option;


const ProblemSelector = (props) => {
  function handleChange(value) {
    //console.log(`selected ${value}`);
    if(value.length===0){
      props.problemIsSelected('none');
    }
    else{
      props.problemIsSelected('block');
    }
    props.problemValue(`${value}`);
  }

  function handleBlur() {
    console.log('blur');
  }

  function handleFocus() {
    console.log('focus');
  }

  return (
    <Card className="gx-card" title="Uploading for?">
      <Select
        mode="multiple"
        showSearch
        style={{width: '100%'}}
        placeholder="Select one of the problems you identified"
        optionFilterProp="children"
        onChange={handleChange}
        onFocus={handleFocus}
        onBlur={handleBlur}
        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
      >
        <Option value="potholes">Potholes</Option>
        <Option value="manholes">Manholes</Option>
        <Option value="road markings">Road Markings</Option>
        <Option value="large objects">Large Objects</Option>
      </Select>
    </Card>
  );
};

export default ProblemSelector;
