import React from "react";
import {Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis} from "recharts";
import {Col, Row, Button} from "antd";

import Widget from "components/Widget/index";

class PRCard extends React.Component {

  constructor(props){
    super(props);
    this.state={
      widgetDisplay: "none",
      buttonText:"Show Demo PR Curve"
    }
  }

  toggleWidget(self){
    if(self.state.widgetDisplay==="none"){
      self.setState({
        widgetDisplay: "block",
        buttonText:"Hide Demo PR Curve"
      });
    }
    else{
      self.setState({
        widgetDisplay: "none",
        buttonText:"Show Demo PR Curve"
      });
    }
  }

  render(){
  return (
    <div>
    <Button block type="primary" onClick={() => this.toggleWidget(this)}>{this.state.buttonText}</Button>
    <div style={{display: this.state.widgetDisplay}}>
    <Widget styleName={`gx-card-full`}>
      <div className="gx-d-flex gx-px-4 gx-pt-4 gx-pb-2">
        <h2 className="h4 gx-text-capitalize gx-mb-0">
          {this.props.cardTitle}</h2>
        {/*<p className="gx-ml-auto gx-text-primary"> Label Selected: Pothole <i className="icon icon-line-chart gx-fs-sm"/></p>*/}
      </div>
      <Row>
        <Col lg={12} md={12} sm={24} xs={24}>
          <div className="gx-actchart gx-pb-5 gx-pl-4">
            <h2 className="gx-fs-xxxl gx-font-weight-medium gx-mb-1 gx-text-black">{this.props.score}</h2>
            <p className="gx-mb-0">{this.props.cardSubTitle}</p>
          </div>
        </Col>
        <Col lg={12} md={12} sm={24} xs={24}>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={this.props.collectedData}
                       margin={{top: 0, right: 0, left: 0, bottom: 0}} >
                       <XAxis dataKey="Label" />
                       <YAxis/>
              <Tooltip/>
              <defs>
                <linearGradient id={this.props.colorId} x1="0" y1="0" x2="1" y2="0">
                  <stop offset="5%" stopColor={this.props.color1} stopOpacity={0.9}/>
                  <stop offset="95%" stopColor={this.props.color2} stopOpacity={0.9}/>
                </linearGradient>
              </defs>
              <Area dataKey="Counter" strokeWidth={0} fill={"url(#"+this.props.colorId+")"}fillOpacity={1}/>
            </AreaChart>
          </ResponsiveContainer>
        </Col>
      </Row>
    </Widget>
    </div>
    </div>
  );
};
}

export default PRCard;
