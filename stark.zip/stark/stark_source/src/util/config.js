module.exports = {
  footerText: 'Copyright Champs Software, Inc. © 2019',
}
